# ANIMOL 맵 제작 참고 자료

Docs/ANIMOL_LLM_MAP_DESIGN_PROMPT.md의 요청문으로 시작하고 가이드와 참고 JSON을 함께 읽으세요.

25개 실제 맵의 좌표·장치·선택한 최단 정답은 참고 JSON에, 입력별 판정은 Docs/Validation/MapDesign/route_analysis.json에 포함했습니다. 행동 가중치는 제안값이며 게임 코스트는 방향 입력 1, 무료 바람 0입니다.

이 묶음은 Unity 프로젝트나 자동 가져오기 패키지가 아닙니다. 원본 소스 및 과거 검증 링크는 저장소 경로로 표시했습니다. PNG는 현재 좌표로 만든 배치도입니다.
